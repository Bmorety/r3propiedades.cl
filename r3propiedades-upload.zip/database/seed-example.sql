INSERT INTO properties
(slug, type, zone, bedrooms, bathrooms, area, price, price_unit, title_es, title_en, desc_es, desc_en, featured, visible, sort_order)
VALUES
('con-3d-mirador', 'anio', 'Concon', 3, 2, 110, 980000, 'mes',
 'Departamento Mirador del Mar', 'Ocean View Apartment',
 'Amplio 3 dormitorios con terraza y vista despejada al Pacifico, en torre con piscina y conserjeria.',
 'Spacious 3-bedroom with terrace and open Pacific views, in a tower with pool and concierge.',
 1, 1, 10),
('ren-2d-dunas', 'temporada', 'Renaca', 2, 2, 78, 95000, 'noche',
 'Frente a las Dunas', 'Facing the Dunes',
 'A pasos de la playa de Renaca. Luminoso, totalmente equipado, ideal para vacaciones en familia.',
 'Steps from Renaca beach. Bright, fully equipped, perfect for a family holiday.',
 1, 1, 20),
('vin-1d-centro', 'anio', 'Vina del Mar', 1, 1, 42, 520000, 'mes',
 'Studio Plaza Vina', 'Plaza Vina Studio',
 'Acogedor 1 dormitorio en pleno centro, cercano a comercio, metro y universidades.',
 'Cozy 1-bedroom in the heart of downtown, near shops, metro and universities.',
 0, 1, 30);
